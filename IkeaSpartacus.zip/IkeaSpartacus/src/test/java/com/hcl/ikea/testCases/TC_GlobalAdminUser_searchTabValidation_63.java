package com.hcl.ikea.testCases;

import org.junit.Assert;
import org.testng.annotations.Test;

import com.hcl.ikea.pageObjects.CureUser_HandoutRequestPage;
import com.hcl.ikea.pageObjects.GlobalAdminUser_SearchTabValidationPage;

public class TC_GlobalAdminUser_searchTabValidation_63 extends BaseClass{
	// Verify the HandOut request for the Cure User
	@Test
	public void searchTabValidation() throws InterruptedException, Exception {
	TC_LoginPageTest_001 lp = new TC_LoginPageTest_001();
	lp.loginPage();
	log.info("Application got login successfully");
	GlobalAdminUser_SearchTabValidationPage globalAdmin = new GlobalAdminUser_SearchTabValidationPage(driver);
	log.info("Calling Cure User handout Request function");
	globalAdmin.searchTabValidation();;
	//Assert.assertTrue("Spare part requested successfully! Print request?", true);
    log.info("Global Admin user is successfully able to verify component details");
	}
	
}
