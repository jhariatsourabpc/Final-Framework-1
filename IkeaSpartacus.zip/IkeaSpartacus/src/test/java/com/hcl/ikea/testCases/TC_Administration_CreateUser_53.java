package com.hcl.ikea.testCases;

import org.testng.annotations.Test;

import com.hcl.ikea.pageObjects.Administration_CreateUserPage;

public class TC_Administration_CreateUser_53 extends BaseClass{
//	Recovery user should be able to add stock successfully
	@Test
	public void createUser() throws InterruptedException, Exception {
			TC_LoginPageTest_001 login = new TC_LoginPageTest_001();
			login.loginPage();
			Administration_CreateUserPage admin= new Administration_CreateUserPage(driver);
			admin.createUser();
			Thread.sleep(1000);
			admin.setUserID(userID);
			Thread.sleep(1000);
	        admin.setUNam(userNm);
	        Thread.sleep(2000);
	        admin.selectRole();
	        Thread.sleep(1000);
	        admin.selectCountry();
	        Thread.sleep(2000);
	        admin.selectStoreID();
	        Thread.sleep(1000);
	        admin.submitClick();
		}
	}

		