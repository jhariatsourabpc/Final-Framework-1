package com.hcl.ikea.testCases;

import org.testng.annotations.Test;

import com.hcl.ikea.pageObjects.Recovery_Manager_CreateUserPage;

import junit.framework.Assert;

@SuppressWarnings("deprecation")
public class TC_Recovery_Manager_CreateUser_59 extends BaseClass{
//	Recovery user should be able to add stock successfully
	@Test
	public void createUser() throws InterruptedException, Exception {
			TC_LoginPageTest_001 login = new TC_LoginPageTest_001();
			login.loginPage();
			Recovery_Manager_CreateUserPage admin= new Recovery_Manager_CreateUserPage(driver);
			admin.createUser();
			Thread.sleep(2000);
			admin.setRMUserID(recoveryManagUserID);
			Thread.sleep(1000);
	        admin.setRMUNam(recoverManagUserName);
	        Thread.sleep(2000);
	        admin.selectRole();
	        //Thread.sleep(1000);
	        //admin.selectCountry();
	        Thread.sleep(2000);
	        admin.selectStoreID();
	        Thread.sleep(1000);
	        admin.selectLanguage();
	        Thread.sleep(1000);
	        admin.submitClick();
	        Thread.sleep(1000);
	        admin.confirmModal();
	        Thread.sleep(2000);
	        admin.searchUserID(recoveryManagUserID);
	        log.info("user is getting added sucessfully by Recovery Manager");
		}
	}

		