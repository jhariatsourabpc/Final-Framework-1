package com.hcl.ikea.testCases;

import org.testng.annotations.Test;

import com.hcl.ikea.pageObjects.RecoveryAdmin_ManageStockCompInventory;
import com.hcl.ikea.pageObjects.RecoveryAdmin_Request;

public class TC_RecoveryAdminRequest_005 extends BaseClass {

	
//	@Test
//	public void cancelRequest()throws InterruptedException, Exception{
//		TC_LoginPageTest_001 login = new TC_LoginPageTest_001();
//		login.loginPage();
//		RecoveryAdmin_Request rR= new RecoveryAdmin_Request(driver);
//		rR.clickOnRequest();
//		rR.cancelRequest();
//	}
	
	@Test
	public void acceptRequest()throws InterruptedException, Exception{
		TC_LoginPageTest_001 login = new TC_LoginPageTest_001();
		login.loginPage();
		RecoveryAdmin_Request rR= new RecoveryAdmin_Request(driver);
		rR.clickOnRequest();
		rR.acceptRequest();
	}

//@Test
//public void rejectRequest()throws InterruptedException, Exception{
//	TC_LoginPageTest_001 login = new TC_LoginPageTest_001();
//	login.loginPage();
//	RecoveryAdmin_Request rR= new RecoveryAdmin_Request(driver);
//	rR.clickOnRequest();
//	rR.rejectRequest();
//}

//@Test
//public void previewRequest()throws InterruptedException, Exception{
//	TC_LoginPageTest_001 login = new TC_LoginPageTest_001();
//	login.loginPage();
//	RecoveryAdmin_Request rR= new RecoveryAdmin_Request(driver);
//	rR.clickOnRequest();
//	rR.previewRequest();
//}
}