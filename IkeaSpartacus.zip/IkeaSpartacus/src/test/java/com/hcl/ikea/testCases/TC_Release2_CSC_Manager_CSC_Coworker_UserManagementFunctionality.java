package com.hcl.ikea.testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcl.ikea.pageObjects.Release2_CSC_Manager_CSC_Coworker_ManagePage;

public class TC_Release2_CSC_Manager_CSC_Coworker_UserManagementFunctionality extends BaseClass{
//	CSC Manager should be able to manager user functionality of CSC_Coworker
	@Test
	public void countryValidation() throws InterruptedException, Exception {
			TC_LoginPageTest_001 login = new TC_LoginPageTest_001();
			login.loginPage();
			Release2_CSC_Manager_CSC_Coworker_ManagePage admin= new Release2_CSC_Manager_CSC_Coworker_ManagePage(driver);
			admin.createCSC_Coworker();
			Thread.sleep(2000);
			admin.selectCountry();
			 Thread.sleep(1000);
	        admin.setCscUserID(cscuserID);
	        Thread.sleep(1000);
	        admin.setcscUNam(cscuserName);
	        Thread.sleep(1000);
	        admin.selectRole();
	        Thread.sleep(5000);
	        admin.selectLanguage();
	        Thread.sleep(1000);
	        admin.submitClick();
	        Thread.sleep(1000);
	        admin.confirmModal();
	        log.info("CSC Manager is successfully able to create CSC Coworker");
	        Thread.sleep(1000);
	        admin.searchUserID(cscuserID);
	        Thread.sleep(2000);
	        admin.scrollDownEditBtn();
	        Thread.sleep(3000);
	        admin.setEditUserNameCSC(editCSCUName);
	        Thread.sleep(1000);
	        admin.submitClick();
	        Thread.sleep(2000);
	        admin.confirmUpdateModal();
	        log.info("CSC Manager is successfully able to edit CSC Coworker details");
	        Thread.sleep(1000);
	        admin.searchClearUserID(cscuserID);
	        Thread.sleep(1000); 
	        admin.scrollDownEditBtn();
	        Thread.sleep(1000);
	        Assert.assertEquals(admin.filterUserName.getText(), "ChandraShekharCSCUser");
	        log.info("CSC is successfully able to handle userManagement functionality of CSC Coworker");
		}
	}

		