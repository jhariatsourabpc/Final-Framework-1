package com.hcl.ikea.testCases;

import org.testng.annotations.Test;

import com.hcl.ikea.pageObjects.Administration_CreateUserPage;
import com.hcl.ikea.pageObjects.Administration_EditUserDetailsPage;

public class TC_Administration_EditUserDetails_54 extends BaseClass{
//	Recovery user should be able to add stock successfully
	@Test
	public void editUser() throws InterruptedException, Exception {
			TC_LoginPageTest_001 login = new TC_LoginPageTest_001();
			login.loginPage();
			Administration_EditUserDetailsPage admin= new Administration_EditUserDetailsPage(driver);
		    admin.editUser();
			Thread.sleep(1000);
			admin.editUserDetails();
			Thread.sleep(1000);
			  admin.editUNam();
			  Thread.sleep(2000); 
			  admin.selectRole(); 
			  Thread.sleep(1000);
			  admin.selectCountry(); 
			  Thread.sleep(2000); 
			  admin.selectStoreID();
			  Thread.sleep(1000); 
			  admin.submitClick();
			 
		}
	}

		