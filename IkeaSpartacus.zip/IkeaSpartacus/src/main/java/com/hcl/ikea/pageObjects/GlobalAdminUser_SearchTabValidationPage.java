package com.hcl.ikea.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class GlobalAdminUser_SearchTabValidationPage {
  
	public WebDriver driver;
	public GlobalAdminUser_SearchTabValidationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//div[@id='changeUserRole']/ul/li/a/span")
	public WebElement role;
	@FindBy(xpath="//input[@name='ctl00$Body$txtSearch' and @id='Body_txtSearch']")
	public WebElement searchTextField;
	@FindBy(xpath="//input[@name='ctl00$Body$btnSearch' and @id='Body_btnSearch']")
	public WebElement searchButton;
	@FindBy(xpath="//table[contains(@class,'dataTableSubDatacontainer Component')]//thead//tr//th[contains(text(),'Part No')]")
	public WebElement partNoHeading;
	@FindBy(xpath="//table[contains(@id,'DataTables_Table_1')]/thead/tr/th[2]")
	public WebElement storeNoHeading;
	//@FindBy(xpath="//div[@id='changeUserCountry']/ul/li/a/span")
	//public WebElement country;
	@FindBy(xpath="ctl00$ddlStore")
    public WebElement storeID;
	@FindBy(xpath="//*[@id='modalRequest']/div[2]/div/div[3]/button[2]")
    public WebElement gotoRequestForm;
	@FindBy(xpath="//*[@id='Body_rptPartDetail_txtQty_0']")
	public WebElement quantity;
	@FindBy(xpath="//*[@id='Body_txtComment']")
	public WebElement comment;
	@FindBy(xpath="//*[@id='Body_ddlRequestReason']")
	public WebElement reason;
	@FindBy(xpath="//*[@id='Body_btnRequest']")
	public WebElement sendToRecovery;
	@FindBy(xpath="//h4[@class='modal-title' and @id='confirm-label']")
	public WebElement confirmModal;
	@FindBy(xpath="//*[@id=\"confirm\"]/div[2]/div/div[3]/button[2]")
	public WebElement cancelBtn;
	@FindBy(xpath="//*[@id='Repeater1_SwitchUserRole_4']")
	public WebElement globalAdminRole;
	
	public void searchTabValidation() throws Exception {
		Actions action = new Actions(driver);
		Thread.sleep(2000);
		action.moveToElement(role).build().perform();
		Thread.sleep(2000);
	    globalAdminRole.click();
		Thread.sleep(1000);
		searchTextField.sendKeys("pax");
		Thread.sleep(1000);
		searchButton.click();
		Thread.sleep(4000);
		int rowNos= driver.findElements(By.xpath("//*[@id='tbl_Articles']/tbody/tr")).size();
		int firstExpandableRow=0;
		String partno1=null;
		String articleno=null;
		    int firstExpandRow=0;
			String storeNo1=null;
			String storeName=null;
		    String location=null;
		    String stockNo=null;
		for(int i=1; i<=rowNos; i++) {
		    driver.findElement(By.xpath("//table[@id='tbl_Articles']/tbody/tr["+Integer.toString(i)+"]/td[1]")).click();
		    Thread.sleep(3000);
		    try{
		    	if(partNoHeading.isDisplayed()) {
		    	firstExpandableRow=i;
				System.out.println("the first part-decribed row is "+firstExpandableRow);
				partno1=driver.findElement(By.xpath("(//table[contains(@class,'dataTableSubDatacontainer Component')]//tbody//tr)[1]//td[3]")).getText();
				articleno=driver.findElement(By.xpath("(//table[@id='tbl_Articles']//tbody//tr//td[contains(@class,' col-md-2 full-width fixLineHeight paddingFix')])["+Integer.toString(i+1)+"]")).getText();
				System.out.println("the partno for which handOut be done "+partno1);
				System.out.println("the Article No for which component should be handOut "+articleno);
				break;
		    	}
		    }catch(Exception e){
		    	System.out.println("No expendable row found for the row number "+i);
		    }
		    int rowNumbers = driver.findElements(By.xpath("//table[contains(@id, 'DataTables_Table_')]/tbody/tr")).size();
		 for(int j=1; j<=rowNumbers; j++) {
			 Thread.sleep(3000);
			  driver.findElement(By.xpath("//table[@id='DataTables_Table_1']/tbody/tr["+Integer.toString(j)+"]/td[1]")).click();
			  try{
			    	if(storeNoHeading.isDisplayed()) {
			    	firstExpandRow=j;
					System.out.println("the first store-decribed row is "+firstExpandRow);
					storeNo1=driver.findElement(By.xpath("(//table[@id='DataTables_Table_4']/tbody/tr[1]/td[2]")).getText();
					storeName=driver.findElement(By.xpath("(//table[@id='DataTables_Table_4']/tbody/tr[1]/td[3]")).getText();
					System.out.println("the partno for which handOut be done "+storeNo1);
					System.out.println("the Article No for which component should be handOut "+storeName);
					break;
			    	}
			    }catch(Exception e){
			    	System.out.println("No expendable row found for the row number "+j);
			    }
		  }  
		}
		/*
		 * Thread.sleep(1000); gotoRequestForm.click(); quantity.sendKeys("2");
		 * comment.sendKeys("test123"); Select select = new Select(reason);
		 * select.selectByValue("1"); Thread.sleep(2000); JavascriptExecutor
		 * js=(JavascriptExecutor)driver; js.executeScript("arguments[0].click()",
		 * sendToRecovery); Thread.sleep(2000); cancelBtn.click();
		 */
	}

}
