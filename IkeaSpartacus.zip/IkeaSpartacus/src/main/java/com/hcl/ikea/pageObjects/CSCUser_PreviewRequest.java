package com.hcl.ikea.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CSCUser_PreviewRequest {

	public WebDriver driver;
	public CSCUser_PreviewRequest(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//div[@id='changeUserRole']/ul/li/a/span")public WebElement role;
	@FindBy(xpath="//input[@name='ctl00$Body$txtSearch' and @id='Body_txtSearch']")public WebElement searchTextField;
	@FindBy(xpath="//input[@name='ctl00$Body$btnSearch' and @id='Body_btnSearch']")public WebElement searchButton;
	@FindBy(xpath="//table[@id='NewRequestsTable']//tbody//tr[1]//td[4]")public WebElement requester;
	@FindBy(xpath="//input[@name='txtUser'] [@id='txtUser']")public WebElement userName;
	@FindBy(xpath="//a//span[normalize-space(.)='Requests' and @title='Requests']") public WebElement requestTab;
	@FindBy(xpath="//table[@id='NewRequestsTable']//tbody//tr[1]//td[7]") public WebElement firstRequestType;
	@FindBy(xpath="") public WebElement rowNewRequest;
	@FindBy(xpath="//table[@id='NewRequestsTable']//tbody//tr[1]//td[1]") public WebElement chevronFirstNewRqst;
	@FindBy(xpath="//table[@id='NewRequestsTable']//tbody//tr[1]//td[2]") public WebElement firstRequestId;
	@FindBy(xpath="//table[@id='NewRequestsTable']//tbody//tr[contains(@class,'selected')]//td//div[@title='Preview']") public WebElement previewBtn;
	@FindBy(xpath="//span[contains(text(),'Welcome')]//span[@id='lblUsername']") public WebElement user ;
	@FindBy(xpath="//select[@id='ddlStore']") public WebElement storeId ;
	@FindBy(xpath="//h4[text()='View Details']//preceding-sibling::button[@class='close']//span") public WebElement closePreview;
	
	public void previewRequest() throws InterruptedException {
		String storeIdNo=storeId.getText().trim();
		Actions action = new Actions(driver);
		Thread.sleep(2000);
		action.moveToElement(role).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@id='Repeater1_SwitchUserRole_3' and normalize-space()='CSC']")).click();
		Thread.sleep(2000);
		searchTextField.sendKeys("pax");
		searchButton.click();
		requestTab.click();
		Thread.sleep(5000);
		String requesterName=requester.getText();
		if(requesterName.contains("/")) {
		int n=requesterName.indexOf("/");
		requesterName=requesterName.substring(0,n);
		}else{
			System.out.println("requesterName: "+requesterName);
		}
		System.out.println("the first request id is : "+ firstRequestId.getText().trim());
		String firstRequestTypeName=firstRequestType.getText();
		chevronFirstNewRqst.click();
		previewBtn.click();
		if(firstRequestTypeName.contains("Asis")||firstRequestTypeName.contains("Repack")||firstRequestTypeName.contains("Show")) {
			driver.findElement(By.xpath("//div[contains(text(),'Requested By')]//following-sibling::div[contains(text(),'"+storeIdNo+"')]")).isDisplayed();
		}else {
		driver.findElement(By.xpath("//div[contains(text(),'Requested By')]//following-sibling::div[contains(text(),'"+requesterName.toLowerCase()+"')]")).isDisplayed();
		}
		driver.findElement(By.xpath("//div[contains(text(),'Request ID')]//following-sibling::div[contains(text(),'"+firstRequestId.getText().trim()+"')]")).isDisplayed();
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", closePreview);
			
	}
}
