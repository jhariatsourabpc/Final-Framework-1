package com.hcl.ikea.pageObjects;

import java.util.concurrent.atomic.AtomicIntegerArray;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Administration_EditUserDetailsPage {
  
	public WebDriver driver;
	public Administration_EditUserDetailsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//div[@id='changeUserRole']/ul/li/a/span")
	public WebElement role;
	@FindBy(xpath="//div[@id='userTable_filter']/label/input")
	public WebElement searchTextField;
	@FindBy(xpath="//table[@id='userTable']/tbody/tr[1]/td[10]/span[@class='edit actButton']")
	public WebElement editButton;
	@FindBy(xpath="//div[@id='changeUserCountry']/ul/li/a/span")
	public WebElement country1;
	@FindBy(xpath="//select[@id='Body_StoreID']")
    public WebElement storeID;
	@FindBy(xpath="//div[@id='sidebar-wrapper']/ul/li[2]/a")
	public WebElement administration;
	@FindBy(xpath="//div[@id='divCheck']/input")
	public WebElement recoveryAdminCheckboxBtn;
	@FindBy(xpath="//*[@id=\"confirm\"]/div[2]/div/div[3]/button[2]")
	public WebElement cancelBtn;
	@FindBy(xpath="//input[@id='Body_UserName']")
	public WebElement userNamee;
	@FindBy(xpath="//input[@id='Body_UserName']")
	public WebElement editNamee;
	@FindBy(xpath="//select[@id='Body_UserLevel']")
	public WebElement userRole;
	@FindBy(xpath="//select[@id='Body_CountryCode']")
	public WebElement country2;
	@FindBy(xpath="//select[@id='Body_CultureID']")
	public WebElement language;
	@FindBy(xpath="//input[@id='Body_UserID']")
	public WebElement userID;
	@FindBy(xpath="//div[@id='divCheck']/following-sibling::div/input[1]")
	public WebElement submitBtn;
	@FindBy(xpath="//div[@id='divCheck']/following-sibling::div/input[2]")
	public WebElement resetBtn;
	@FindBy(xpath="//div[@id='sidebar-wrapper']/ul/li[2]/ul/li[4]")
	public WebElement userManagement;
	@FindBy(xpath="//a[@id='Repeater1_SwitchUserRole_5']")
	public WebElement adminRole;
	
	public void editUser() throws Exception {
		Actions action = new Actions(driver);
		Thread.sleep(2000);
		action.moveToElement(role).build().perform();
		Thread.sleep(2000);
		adminRole.click();
		Thread.sleep(1000);
		action.moveToElement(administration).build().perform();
		Thread.sleep(2000);
		userManagement.click();
	}
	
	public void editUserDetails() throws Exception {
		Actions action = new Actions(driver);
		int y1 = searchTextField.getLocation().getY();
	    System.out.println("Y coordinate of searchTextField is " +y1);
	    JavascriptExecutor js1 = (JavascriptExecutor)driver;
	    js1.executeScript("window.scrollBy(0,446)", "");
		Thread.sleep(2000);
		searchTextField.sendKeys("chtri8");
		Thread.sleep(3000);
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='userTable']/tbody/tr[1]/td[10]/span[@class='edit actButton']")));
		jse.executeScript("arguments[0].click()", editButton);
	}

	/*
	 * public void setUserID(String uID) { userID.sendKeys(uID); }
	 */
	public void editUNam() {
		editNamee.clear();
		editNamee.sendKeys("ChandraShekaruser101");
	}
	public void selectRole() {
		Select sel = new Select(userRole);
	    sel.selectByValue("7");
	}
	public void selectCountry() {
		Select sel = new Select(country2);
	    sel.selectByValue("BE");
	}
	public void selectStoreID() {
		Select sel = new Select(storeID);
	    sel.selectByValue("375 ");
	}
	public void submitClick() {
		submitBtn.click();
	}
}
