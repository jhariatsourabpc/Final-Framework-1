package com.hcl.ikea.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CureUser_PreviewRequestPage {
  
	public WebDriver driver;
	public CureUser_PreviewRequestPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//div[@id='changeUserRole']/ul/li/a/span")
	public WebElement role;
	@FindBy(xpath="//div[@id='sidebar-wrapper']/ul/li[3]")
	public WebElement requests;
	@FindBy(xpath="//div[@id='changeUserCountry']/ul/li/a/span")
	public WebElement country;
	@FindBy(xpath="ctl00$ddlStore")
    public WebElement storeID;
    @FindBy(xpath="//table[@id='DataTables_Table_0']//thead//tr//th[contains(text(),'Part No')]")
    public WebElement partNoHeading;
	@FindBy(xpath="//div[@id='sidebar']/div[@class='c01147']/div/button[1]/span")
	public WebElement printBtn;
	@FindBy(xpath="//div[@id='iKeaModal']/div[2]/div/div/button")
    public WebElement modalCloseBtn;
	@FindBy(xpath="//h4[@id='gridSystemModalLabel']")
    public WebElement modalTitle;
	@FindBy(xpath="//div[@id='confirm']/div[2]/div/div[2]/p")
	public WebElement confirmModalMessage;
	@FindBy(xpath="//select[@name='ctl00$Body$ddlRequestReason' and @id='Body_ddlRequestReason']")
	public WebElement reason2;
	@FindBy(xpath="//div[@id='confirm']//div[3]/button[1]")
	public WebElement modalConfirmOkBtn;
	@FindBy(xpath="//div[@id='confirm']/div[2]/div/child::div[3]/button[2]")
	public WebElement modalConfirmCancelBtn;
	
	@SuppressWarnings("unlikely-arg-type")
	public void previewRequest() throws Exception {
		Actions action = new Actions(driver);
		Thread.sleep(2000);
		action.moveToElement(role).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='Repeater1_SwitchUserRole_2']")).click();
		Thread.sleep(1000);
		action.moveToElement(country).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='Repeater2_SwitchUserCountry_3']")).click();
		Thread.sleep(2000);
		/*
		 * searchTextField.sendKeys("pax"); searchButton.click(); Thread.sleep(3000);
		 * int rowNos=
		 * driver.findElements(By.xpath("//*[@id='tbl_Articles']/tbody/tr")).size(); int
		 * firstExpandableRow=0; String partno1=null; String articleno=null; WebElement
		 * partialExchangeBtn; for(int i=1; i<=rowNos; i++) {
		 * driver.findElement(By.xpath("//table[@id='tbl_Articles']/tbody/tr["+Integer.
		 * toString(i)+"]/td[1]")).click(); try{ if(partNoHeading.isDisplayed()) {
		 * firstExpandableRow=i;
		 * System.out.println("the first part-decribed row is "+firstExpandableRow);
		 * partno1=driver.findElement(By.
		 * xpath("(//table[contains(@class,'dataTableSubDatacontainer Component')]//tbody//tr)[1]//td[2]"
		 * )).getText(); articleno=driver.findElement(By.
		 * xpath("(//table[@id='tbl_Articles']//tbody//tr//td[contains(@class,' col-md-2 full-width fixLineHeight paddingFix')])["
		 * +Integer.toString(i+1)+"]")).getText();
		 * System.out.println("the partno for which issue report to be done "+partno1);
		 * System.out.
		 * println("the Article No for which component should be issue report "
		 * +articleno); break; } }catch(Exception e){
		 * System.out.println("No expendable row found for the row number "+i); } }
		 * Thread.sleep(2000); partialExchangeBtn=driver.findElement(By.xpath(
		 * "//table[@id='tbl_Articles']/tbody/tr[1]/td[5]/div[2]"));
		 * partialExchangeBtn.click(); Thread.sleep(1000); plusbtn.click();
		 * gotoRequestForm.click(); Select select = new Select(reason1);
		 * select.selectByValue("4"); goToRequestFormCTA.click(); Thread.sleep(1000);
		 */
		action.moveToElement(requests).build().perform();
		requests.click();
		Thread.sleep(3000);
		/*
		 * int rowNos=
		 * driver.findElements(By.xpath("//table[@id='NewRequestsTable']/tbody/tr")).
		 * size(); int firstExpandableRow=0; String partno1=null; String Idno1=null;
		 */
		WebElement previewRequestBtn;
		//for(int i=1; i<=rowNos; i++) {
		driver.findElement(By.xpath("//table[@id='NewRequestsTable']/tbody/tr[1]/td[1]")).click();
			/*
			 * try{ if(partNoHeading.isDisplayed()) { firstExpandableRow=i;
			 * System.out.println("the first part-decribed row is "+firstExpandableRow);
			 * partno1=driver.findElement(By.xpath(
			 * "(//table[@id='DataTables_Table_2']/tbody/tr["+Integer.toString(i)+"]/td[2]")
			 * ).getText(); Idno1=driver.findElement(By.xpath(
			 * "//table[@id='NewRequestsTable']/thead/following-sibling::tbody/tr["+Integer.
			 * toString(i)+"]/td[2]")).getText();
			 * System.out.println("the partno for which cancelRequest to be handle "+partno1
			 * ); System.out.println("the ID No for which cancel request should be handle "
			 * +Idno1); break; } }catch(Exception e){
			 * System.out.println("No expendable row found for the row number "+i); } }
			 */
		Thread.sleep(1000);
		previewRequestBtn=driver.findElement(By.xpath("//table[@id='NewRequestsTable']/thead/following-sibling::tbody/tr[1]/td[9]/div[contains(@class,'actButton edit')]"));
		action.moveToElement(previewRequestBtn).build().perform();
		Thread.sleep(1000);
		previewRequestBtn.click();
		Thread.sleep(2000);
		if(driver.getTitle().equals(modalTitle)) {
			modalCloseBtn.click();
		}
		/*
		 * Thread.sleep(3000); String ParentPage = driver.getWindowHandle(); Set<String>
		 * s1= driver.getWindowHandles(); Iterator<String> i1 = s1.iterator();
		 * while(i1.hasNext()) { String FirstChildPage = i1.next();
		 * if(!ParentPage.equalsIgnoreCase(FirstChildPage)) {
		 * driver.switchTo().window(FirstChildPage); Thread.sleep(1000);
		 * printBtn.click(); } }
		 */
		
		
		//JavascriptExecutor js= (JavascriptExecutor)driver;
		//js.executeScript("arguments[0].click()", cancelRequestBtn);
		/*
		 * if(confirmModalMessage.equals("Cancel the selected request?")) {
		 * modalConfirmOkBtn.click(); }else { modalConfirmCancelBtn.click(); }
		 */
	}

}
