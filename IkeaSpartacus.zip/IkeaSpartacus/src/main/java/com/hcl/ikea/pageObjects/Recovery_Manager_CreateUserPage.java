package com.hcl.ikea.pageObjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Recovery_Manager_CreateUserPage {
  
	public WebDriver driver;
	public Recovery_Manager_CreateUserPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//div[@id='changeUserRole']/ul/li/a/span")
	public WebElement role;
	@FindBy(xpath="//div[@id='userTable_filter']/label/input")
	public WebElement searchTextField;
	@FindBy(xpath="//input[@name='ctl00$Body$btnSearch' and @id='Body_btnSearch']")
	public WebElement searchButton;
	@FindBy(xpath="//div[@id='changeUserCountry']/ul/li/a/span")
	public WebElement country1;
	@FindBy(xpath="//select[@id='Body_StoreID']")
    public WebElement storeID;
	@FindBy(xpath="//a[@id='Repeater1_SwitchUserRole_7']")
	public WebElement recoveryManagerRole;
	@FindBy(xpath="//h4[@class='modal-title' and @id='confirm-label']")
	public WebElement confirmModal;
	@FindBy(xpath="//*[@id=\"confirm\"]/div[2]/div/div[3]/button[2]")
	public WebElement cancelBtn;
	@FindBy(xpath="//input[@id='Body_UserName']")
	public WebElement userNamee;
	@FindBy(xpath="//select[@id='Body_UserLevel']")
	public WebElement userRole;
	@FindBy(xpath="//select[@id='Body_CountryCode']")
	public WebElement country2;
	@FindBy(xpath="//select[@id='Body_CultureID']")
	public WebElement language;
	@FindBy(xpath="//input[@id='Body_UserID']")
	public WebElement userID;
	@FindBy(xpath="//div[@id='divCheck']/following-sibling::div/input[1]")
	public WebElement submitBtn;
	@FindBy(xpath="//div[@id='divCheck']/following-sibling::div/input[2]")
	public WebElement resetBtn;
	@FindBy(xpath="//div[@id='sidebar-wrapper']/ul/li[2]/ul/li[4]")
	public WebElement userManagement;
	@FindBy(xpath="//a[@id='Repeater2_SwitchUserCountry_1']")
	public WebElement countrySelection;
	@FindBy(xpath="//a[@id='Repeater1_SwitchUserRole_5']")
	public WebElement adminRole;
	@FindBy(xpath="//div[@id='confirm']/div[2]/div/div[2]/p")
	public WebElement confirmModalMessage;
	@FindBy(xpath="//div[@id='confirm']/div[2]/div/div[3]/button[1]")
	public WebElement confirmModalOkBtn;
	@FindBy(xpath="//div[@id='confirm']/div[2]/div/div[3]/button[2]")
	public WebElement confirmModalCancelBtn;
	
	public void createUser() throws Exception {
		Actions action = new Actions(driver);
		Thread.sleep(2000);
		action.moveToElement(role).build().perform();
		Thread.sleep(2000);
		recoveryManagerRole.click();
		Thread.sleep(1000);
		action.moveToElement(country1).build().perform();
		Thread.sleep(2000);
		countrySelection.click();
		/*
		 * Thread.sleep(1000); userID.click(); userID.sendKeys(); Thread.sleep(2000);
		 * searchTextField.sendKeys("pax"); searchButton.click(); Thread.sleep(3000);
		 * int rowNos=
		 * driver.findElements(By.xpath("//*[@id='tbl_Articles']/tbody/tr")).size(); int
		 * firstExpandableRow=0; String partno1=null; String articleno=null; WebElement
		 * handOutBtn; for(int i=1; i<=rowNos; i++) {
		 * driver.findElement(By.xpath("//table[@id='tbl_Articles']/tbody/tr["+Integer.
		 * toString(i)+"]/td[1]")).click(); try{ if(partNoHeading.isDisplayed()) {
		 * firstExpandableRow=i;
		 * System.out.println("the first part-decribed row is "+firstExpandableRow);
		 * partno1=driver.findElement(By.
		 * xpath("(//table[contains(@class,'dataTableSubDatacontainer Component')]//tbody//tr)[1]//td[2]"
		 * )).getText(); articleno=driver.findElement(By.
		 * xpath("(//table[@id='tbl_Articles']//tbody//tr//td[contains(@class,' col-md-2 full-width fixLineHeight paddingFix')])["
		 * +Integer.toString(i+1)+"]")).getText();
		 * System.out.println("the partno for which handOut be done "+partno1);
		 * System.out.println("the Article No for which component should be handOut "
		 * +articleno); break; } }catch(Exception e){
		 * System.out.println("No expendable row found for the row number "+i); } }
		 * Thread.sleep(2000); handOutBtn=driver.findElement(By.
		 * xpath("//div[@class='col-lg-12 maincontent']/div[2]/div/div/div[2]/table/tbody/tr[2]/td/div/div/child::div[2]/table/child::tbody/tr[1]/td[6]/div[1]"
		 * )); handOutBtn.click(); Thread.sleep(1000); gotoRequestForm.click();
		 * quantity.sendKeys("2"); comment.sendKeys("test123"); Select select = new
		 * Select(reason); select.selectByValue("1"); Thread.sleep(2000);
		 * JavascriptExecutor js=(JavascriptExecutor)driver;
		 * js.executeScript("arguments[0].click()", sendToRecovery); Thread.sleep(2000);
		 * cancelBtn.click();
		 */
	}
	public void setRMUserID(String uRMID) throws Exception {
		userID.click();
		Thread.sleep(1000);
		userID.sendKeys("aasri");
	}
	public void setRMUNam(String usrRMNm) {
		userNamee.sendKeys(usrRMNm);
	}
	public void selectRole() {
		Select sel = new Select(userRole);
	    sel.selectByValue("2");
	}

	public void selectStoreID() {
		Select sel = new Select(storeID);
	    sel.selectByValue("372 ");
	}
	  public void selectLanguage() { 
		  Select sel = new Select(language);
	  sel.selectByValue("1"); 
	  }
	public void submitClick() {
		submitBtn.click();
	}
	public void confirmModal() {
		if(confirmModalMessage.getText().equals("Are you sure you want to add this User?")) {
			confirmModalOkBtn.click();
		}else {
		  confirmModalCancelBtn.click();   
		}	
	}
	public void searchUserID(String userRMID) throws Exception {
		Actions action = new Actions(driver);
		int x = searchTextField.getLocation().getX();
		System.out.println("X coordinate of searchtextField web element is "+x);
		int y = searchTextField.getLocation().getY();
		System.out.println("Y coordinate of searchtextField web element is "+y);
		action.moveToElement(searchTextField, x, y).click();
		Thread.sleep(3000);
	    searchTextField.sendKeys("aasri");
}
}
