package com.hcl.ikea.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class CSCUser_HandoutRequestPage {
  
	public WebDriver driver;
	public CSCUser_HandoutRequestPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//div[@id='changeUserRole']/ul/li/a/span")public WebElement role;
	@FindBy(xpath="//input[@name='ctl00$Body$txtSearch' and @id='Body_txtSearch']")public WebElement searchTextField;
	@FindBy(xpath="//input[@name='ctl00$Body$btnSearch' and @id='Body_btnSearch']")public WebElement searchButton;
	@FindBy(xpath="//table[contains(@class,'dataTableSubDatacontainer Component')]//thead//tr//th[contains(text(),'Part No')]")public WebElement partNoHeading;
	@FindBy(xpath="//table[contains(@class,'dataTableSubDatacontainer')]//thead//th[text()='Store']")public WebElement Store;
	@FindBy(xpath="//select[contains(@id,'CountryCode')]")public WebElement country;
	@FindBy(xpath="(//input[@type='number' and contains(@class,'salesQty')])[1]")public WebElement quantity;
	@FindBy(xpath="//button[@id='btnSubmit']")public WebElement submit;
	@FindBy(xpath="//button[contains(@class,'confirm') and normalize-space(.)='OK']") public WebElement okButn;
	@FindBy(xpath="ctl00$ddlStore")public WebElement storeID;
	@FindBy(xpath="//table[@id='DataTables_Table_2']/tbody/tr[1]/td[6]/div[2]")public WebElement reserveCta;
	@FindBy(xpath="//table[@id='DataTables_Table_0']/tbody/tr[1]/td[6]/input")public WebElement quantity1;
	@FindBy(xpath="//table[@id='DataTables_Table_0']/tbody/tr[4]/td[6]/input")public WebElement quantity2;
	@FindBy(xpath="//textarea[contains(@class,'AdditionalComment')]")public WebElement comment;
	@FindBy(xpath="//*[@id='Body_ddlRequestReason']")public WebElement reason;
	@FindBy(xpath="//button[@id='btnSubmit']")public WebElement submitRequest;
	@FindBy(xpath="//h4[@id='confirm-label']")public WebElement confirmModalTitle;
	@FindBy(xpath="//div[@id='confirm']/div[2]/div/div[3]/button[2]")public WebElement cancelBtn;
	@FindBy(xpath="//div[@id='confirm']/div[2]/div/div[3]/button[1]")public WebElement okBtn;
	
	public void cscUserhandOutrequest() throws Exception {
		Actions action = new Actions(driver);
		Thread.sleep(2000);
		action.moveToElement(role).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@id='Repeater1_SwitchUserRole_3']")).click();
		Thread.sleep(2000);
		searchTextField.sendKeys("pax");
		searchButton.click();
		Thread.sleep(3000);
		int rowNos= driver.findElements(By.xpath("//*[@id='tbl_Articles']/tbody/tr")).size();
		int firstExpandableRow=0;
		String partno1=null;
		String articleno=null;
		WebElement expandBtn;
		for(int i=1; i<=rowNos; i++) {
		    driver.findElement(By.xpath("//table[@id='tbl_Articles']/tbody/tr["+Integer.toString(i)+"]/td[1]")).click();
		    try{
		    	if(partNoHeading.isDisplayed()) {
		    	firstExpandableRow=i;
				System.out.println("the first part-decribed row is "+firstExpandableRow);
				partno1=driver.findElement(By.xpath("(//table[contains(@class,'dataTableSubDatacontainer Component')]//tbody//tr)[1]//td[2]")).getText();
				articleno=driver.findElement(By.xpath("(//table[@id='tbl_Articles']//tbody//tr//td[contains(@class,' col-md-2 full-width fixLineHeight paddingFix')])["+Integer.toString(i+1)+"]")).getText();
				System.out.println("the partno for which handOut be done "+partno1);
				System.out.println("the Article No for which component should be handOut "+articleno);
				break;
		    	}
		    }catch(Exception e){
		    	System.out.println("No expendable row found for the row number "+i);
		    }
		}
		int size1stInnerRow=driver.findElements(By.xpath("//table[contains(@class,'dataTableSubDatacontainer Component')]//tbody//tr")).size();
		for(int j=1;j<=size1stInnerRow;j++) {
			driver.findElement(By.xpath("//table[contains(@class,'dataTableSubDatacontainer Component')]//tbody//tr["+Integer.toString(j)+"]//td[1]")).click();
			try {
			   if(Store.isDisplayed()) {
				int storeRowNos=driver.findElements(By.xpath("//table[contains(@class,'dataTableSubDatacontainer')]//thead//th[text()='Store']//parent::tr//parent::thead//parent::table//tbody//tr")).size();
			    for(int k=1;k<=storeRowNos;k++) {
			    String stockNo=driver.findElement(By.xpath("//table[contains(@class,'dataTableSubDatacontainer')]//thead//th[text()='Store']//parent::tr//parent::thead//parent::table//tbody//tr["+Integer.toString(k)+"]//td[5]")).getText();
			    int stockNum=Integer.parseInt(stockNo);
			    if(stockNum!=0) {
			    	driver.findElement(By.xpath("//table[contains(@class,'dataTableSubDatacontainer')]//thead//th[text()='Store']//parent::tr//parent::thead//parent::table//tbody//tr["+Integer.toString(k)+"]//td[6]//div[@title='Reserve']")).click();
//			    	quantity.sendKeys("10");
			    	int comps=driver.findElements(By.xpath("//input[@type='number' and contains(@class,'salesQty')]")).size();
			    	for(int c=1;c<=comps;c++) {
			    		driver.findElement(By.xpath("(//input[@type='number' and contains(@class,'salesQty')])["+Integer.toString(c)+"]")).sendKeys("1");
			    	}
			    	JavascriptExecutor jse = (JavascriptExecutor)driver;
			    	jse.executeScript("arguments[0].click()", submit);
//			    	submit.click();
			    	okButn.click();
			    	break;
			      }
			     }
			      break;
			   }
			   
			}catch(Exception e) {
				
			}
		}

	}

}
